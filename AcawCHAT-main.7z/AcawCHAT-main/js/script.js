// Pastikan accounts.js telah di-load sebelum script ini
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Cek apakah username dan password cocok dengan akun yang ada
    const user = accounts.find(
        account => account.username === username && account.password === password
    );

    if (user) {
        alert("Login Berhasil!");
        window.location.href = "welcome.html";
    } else {
        document.getElementById("errorMessage").textContent = "Username atau password salah!";
    }
});
