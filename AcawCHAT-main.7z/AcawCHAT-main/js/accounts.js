// Daftar akun disimpan di sini
const accounts = [
    { username: "gerall", password: "gerall" },
    { username: "admin", password: "admin123" },
    { username: "user", password: "user123" }
];
